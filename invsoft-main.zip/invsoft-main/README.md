# covlocation-project

Projeto desenvolvido para a disciplina Engenharia de Software do curso de Engenharia da Computação.

Link para o vídeo do projeto sendo executado: https://www.youtube.com/watch?v=xajcKgxZh_A&ab_channel=covlocation

Link para slides: https://docs.google.com/presentation/d/1ouqxEaEPSqBcbQFhwp14Kbv0rZLdm_-jUsRGP51RG48/edit?usp=sharing

Para executar com nodemon: npm run dev:start


